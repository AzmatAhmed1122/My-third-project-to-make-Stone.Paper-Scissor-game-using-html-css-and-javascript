let scissors=document.querySelector(".box1");
let paper=document.querySelector(".box2");
let stone=document.querySelector(".box3");
let user=document.querySelector(".first44 .firstparaed");
let computer=document.querySelector("#second55 .secondpara12");
let pickmovewhenuserwinthenitgreen=document.querySelector(".lastdiv");

let userpoint=0;
let computerpoint=0;

const choice=["scissors","paper","stone"];

//First event when click on scissor
scissors.addEventListener("click",()=>sfunction1("scissors"));



//Second event when click on paper
paper.addEventListener("click",()=>sfunction1("paper"));



//Third event when click on stone
stone.addEventListener("click",()=>sfunction1("stone"));


//Make first function
function sfunction1(userchoice){
	let computerchoice=choice[Math.floor(Math.random()*choice.length)];
	if(userchoice===computerchoice){
		alert("Its a tie!");
	}
	else if(userchoice=="scissors"&&computerchoice=="paper"||
userchoice=="paper"&&computerchoice=="scissors"||
userchoice=="stone"&&computerchoice=="paper"){
		userpoint++;
	user.innerText=userpoint;
	alert("user win");
	pickmovewhenuserwinthenitgreen.style.backgroundColor="green";
	pickmovewhenuserwinthenitgreen.style.color="white";
	}
	else{
computerpoint++;
computer.innerText=computerpoint;
	alert("computer win");
	pickmovewhenuserwinthenitgreen.style.backgroundColor="red";
	pickmovewhenuserwinthenitgreen.style.color="white";
	pickmovewhenuserwinthenitgreen.innerText="computer Win";
}




	
}
